from pathlib import Path

def test_required_directories_exist():
    for name in ["src/bot", "src/ai", "src/github", "src/audit", "src/reports", "src/security"]:
        assert Path(name).is_dir()
