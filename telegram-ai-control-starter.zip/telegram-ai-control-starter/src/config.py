import os
from dotenv import load_dotenv

load_dotenv()

def csv_ints(value: str) -> set[int]:
    result = set()
    for part in (value or "").split(","):
        part = part.strip()
        if part:
            try:
                result.add(int(part))
            except ValueError:
                raise ValueError("TELEGRAM_ADMIN_IDS must contain numeric IDs separated by commas")
    return result

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_IDS = csv_ints(os.getenv("TELEGRAM_ADMIN_IDS", ""))
DEFAULT_AI_PROVIDER = os.getenv("DEFAULT_AI_PROVIDER", "groq").strip().lower()
