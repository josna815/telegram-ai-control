from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from src.config import BOT_TOKEN, ADMIN_IDS

dp = Dispatcher()

def is_admin(message: Message) -> bool:
    return bool(message.from_user and message.from_user.id in ADMIN_IDS)

@dp.message(Command("start"))
async def start(message: Message):
    if not is_admin(message):
        await message.answer("এই বটটি ব্যক্তিগতভাবে সীমাবদ্ধ। Admin-এর অনুমতি প্রয়োজন।")
        return
    await message.answer(
        "স্বাগতম! Telegram AI Control Bot চালু হয়েছে।\n"
        "/help — কমান্ড তালিকা\n"
        "/health — বটের অবস্থা"
    )

@dp.message(Command("help"))
async def help_command(message: Message):
    if not is_admin(message):
        return
    await message.answer("/start\n/help\n/health")

@dp.message(Command("health"))
async def health(message: Message):
    if not is_admin(message):
        return
    await message.answer("Bot: online\nAI: not connected yet\nGitHub Audit: not connected yet")

@dp.message()
async def fallback(message: Message):
    if not is_admin(message):
        return
    await message.answer("Core bot চালু আছে। AI provider পরবর্তী ধাপে যুক্ত হবে।")

async def run_bot():
    if not BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is missing. Copy .env.example to .env and add your token.")
    if not ADMIN_IDS:
        raise RuntimeError("TELEGRAM_ADMIN_IDS is empty. Add your numeric Telegram user ID.")
    bot = Bot(token=BOT_TOKEN)
    await dp.start_polling(bot)
