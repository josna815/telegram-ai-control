"""Provider routing placeholder.

পরবর্তী ধাপে Gemini/Groq/OpenAI/OpenRouter-এর আলাদা adapter যোগ হবে।
Provider fallback হবে availability/error handling-এর জন্য; quota বা free-tier limit
পাশ কাটানোর জন্য account rotation করা হবে না।
"""

class AIUnavailable(RuntimeError):
    pass

async def generate_reply(prompt: str) -> str:
    raise AIUnavailable("No AI provider adapter configured yet.")
