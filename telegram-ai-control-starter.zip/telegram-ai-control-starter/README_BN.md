# Telegram AI Control Bot — Starter Structure

এটি Zero-cost-first development starter। এটি এখনই পূর্ণাঙ্গ AI/GitHub অডিট সিস্টেম নয়; প্রথমে Telegram Bot + নিরাপদ configuration scaffold।

## শুরুর নিয়ম
1. Python 3.11+ ইনস্টল করুন।
2. এই ফোল্ডার GitHub repository-তে আপলোড করুন।
3. `.env.example` কপি করে `.env` করুন।
4. BotFather থেকে একটি Telegram bot token নিন এবং `.env`-এ বসান।
5. `pip install -r requirements.txt`
6. `python main.py`
7. Telegram-এ বটকে `/start` দিন।

## Zero-cost বাস্তবতা
- Telegram Bot API: সাধারণ bot ব্যবহারে বিনামূল্যে।
- GitHub Actions: নির্দিষ্ট সীমার free minutes/storage; সীমা অতিক্রম করলে খরচ হতে পারে।
- Gemini/Groq/OpenRouter/OpenAI: প্রতিটির free tier, quota, model availability ও শর্ত আলাদা এবং পরিবর্তনশীল।
- একাধিক Gmail/Google account তৈরি করলেই একটি API-এর quota বৈধভাবে যোগ হয়ে যায় না। Free-tier সীমা পাশ কাটাতে account rotation করা provider-এর শর্ত ভঙ্গ করতে পারে। এই starter-এ quota bypass বা key rotation করে limit এড়ানোর ব্যবস্থা নেই।
- একাধিক provider যুক্ত করা হবে fallback/availability-এর জন্য, quota bypass-এর জন্য নয়।

## ফোল্ডারের মানচিত্র
- `src/bot/` Telegram handlers ও commands
- `src/ai/` provider adapters এবং fallback router
- `src/github/` GitHub integration placeholders
- `src/audit/` project detection/audit placeholders
- `src/reports/` report output
- `src/security/` admin allowlist ও approval checks
- `src/database/` ভবিষ্যৎ database layer
- `tests/` automated tests
- `.github/workflows/` audit workflow starter

## গুরুত্বপূর্ণ নিরাপত্তা
- `.env` কখনো GitHub-এ commit করবেন না।
- API key/token কাউকে পাঠাবেন না।
- Bot কেবল `TELEGRAM_ADMIN_IDS`-এ থাকা user-দের command চালাতে দেবে।
- AI-কে সরাসরি shell command চালানোর অনুমতি দেবেন না।
- এই starter-এ production deployment নেই এবং থাকবে না, যতক্ষণ না আলাদা manual approval workflow তৈরি হয়।

## পরবর্তী ধাপ
প্রথমে Telegram Core Bot চালু করে `/health` পরীক্ষা করুন। এরপর একটি করে AI provider যুক্ত করুন। সব provider একসঙ্গে চালু করার দরকার নেই।
