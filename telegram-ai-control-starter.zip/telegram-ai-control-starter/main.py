import asyncio
from src.bot.telegram import run_bot

if __name__ == "__main__":
    asyncio.run(run_bot())
